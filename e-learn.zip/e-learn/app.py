from email import contentmanager
from msilib.schema import File
from re import sub
import re
from select import select
from tkinter.messagebox import QUESTION
from traceback import print_tb
from unicodedata import name
# from django import db
from flask import Flask,render_template,request, request_started,session,jsonify
from DBConnection import Db
import random
app = Flask(__name__)
app.secret_key="333"

@app.route('/')
def hello_world():
    return render_template("login.html")

@app.route('/addcourse')
def addcourse():
    db=Db()
    qry="select * from department"
    res=db.select(qry)
    return render_template("admin/addcourse.html",data=res)

@app.route('/addcourse_post',methods=['post'])
def addcourse_post():
    db=Db()
    course=request.form['textfield']
    deprt=request.form['select']
    totalsem=request.form['textfield2']
    qry="insert into course(course_name,department_id,total_sem)values('"+course+"','"+deprt+"','"+totalsem+"')"
    res=db.insert(qry)
    return  addcourse()



@app.route('/adddepartment')
def adddepartment():
    return render_template("admin/adddepartment.html")
@app.route('/adddepartment_post',methods=['post'])
def adddepartment_post():
    db=Db()
    department=request.form['textfield']
    qry="insert into department(department_name)values('"+department+"')"
    res=db.insert(qry)
    return adddepartment()



@app.route('/addstaff')
def addstaff():
    db = Db()
    qry = "select * from department"
    res = db.select(qry)

    return render_template("admin/addstaff.html",data=res)
@app.route('/addstaff_post',methods=['post'])
def addstaff_post():
    db=Db()
    import datetime
    # pname=datetime.strftime()

    name=request.form['textfield']
    gender=request.form['RadioGroup1']
    dob=request.form['textfield2']
    housename=request.form['textfield3']
    place=request.form['textfield4']
    city = request.form['textfield5']
    district = request.form['textfield6']
    # state=request.form['s1']
    pin = request.form['textfield7']
    image=request.files['fileField']
    image.save("D:\\project\\project\\ilahiya\\e-learn\\static\\staff\\"+image.filename)
    path = "/static/staff/"+image.filename
    email=request.form['textfield8']
    contact=request.form['textfield9']
    department=request.form['select']
    password = random.randint(10000,99999)
    qry1 = "INSERT INTO login(`username`,`password`,`usertype`) VALUES('"+email+"','"+str(password)+"','staff')"
    res1 = db.insert(qry1)
    qry="INSERT INTO staff(`department_id`,`login_id`,`name`,`place`,`email`,`pin`,`contact`,`gender`,`image`,`district`,`housename`,`dob`,`city`) VALUES('"+department+"','"+str(res1)+"','"+name+"','"+place+"','"+email+"','"+pin+"','"+contact+"','"+gender+"','"+path+"','"+district+"','"+housename+"','"+dob+"','"+city+"')"

    res=db.insert(qry)
    return '''<script>alert('Successfully added');window.location='/addstaff'</script>'''


@app.route('/addsubject')
def addsubject():
    db = Db()
    qry = "select * from course"
    res = db.select(qry)
    return render_template("admin/addsubject.html",data=res)



@app.route('/addsubject_post',methods=['post'])
def addsubject_post():
    db=Db()
    course=request.form['select']
    semester=request.form['textfield']
    subject=request.form['textfield2']
    qry="insert into subject(course_id,semester,subject_name)values('"+course+"','"+semester+"','"+subject+"') "
    res=db.insert(qry)
    return addsubject()
@app.route('/editcourse/<id>')
def editcourse(id):
    session['csidd']=id
    db=Db()
    qry = "select * from course where course_id='"+id+"'"
    res=db.selectOne(qry)
    print(res)
    qry1="select * from department"
    res1 = db.select(qry1)
    print("==============================")
    qry2 = "select department.* from department,course where course.department_id=department.department_id and course.course_id='"+id+"'"
    res2 = db.selectOne(qry2)
    print(qry2)
    return render_template("admin/editcourse.html",data=res,data2=res2,data1=res1)


@app.route('/editcourse_post',methods=['post'])
def editcourse_post():
    department=request.form['select']
    course=request.form['textfield']
    TotalSemester=request.form['textfield2']
    id=request.form["cid"]
    db=Db()
    qry="update course set course_name='"+course+"' where course_id='"+id+"'"
    res=db.update(qry)
    return '''<script>alert('updated');window.location='/viewcourse'</script>'''

@app.route('/editdepartment/<id>')
def editdepartment(id):
    db=Db()
    qry="select * from department  where department_id='"+id+"'"
    res=db.selectOne(qry)
    print(res)
    return render_template("admin/editdepartment.html",data=res)


@app.route('/editdeparment_post',methods=['post'])
def editdepartment_post():
    dep_id=request.form['dep_id']
    dep_name=request.form['textfield']
    db = Db()
    qry="update department set department_name='"+dep_name+"' where department_id='"+str(dep_id)+"'"
    res=db.update(qry)
    return '''<script>alert('updated');window.location='/viewdepartment'</script>'''

@app.route('/editstaff/<id>')
def editstaff(id):
    db=Db()
    qry = "select * from staff where staff_id='"+id+"'"
    res = db.selectOne(qry)
    print(res)
    qry1="select * from department"
    res1=db.select(qry1)

    return render_template("admin/editstaff.html",data=res,data1=res1)


@app.route('/editstaff_post',methods=['post'])
def editstaff_post():
    staffid=request.form['staffid']
    name=request.form['textfield']
    gender=request.form['RadioGroup1']
    dob=request.form['textfield2']
    house=request.form['textfield3']
    place=request.form['textfield4']
    city=request.form['textfield5']
    # state=request.form['textfield6']
    pin=request.form['textfield7']
    email=request.form['textfield8']
    contact=request.form['textfield9']
    department=request.form['select']
    district=request.form['textfield10']
    if 'fileField' in request.files:
        image = request.files['fileField']


        if image.filename!='':
            image.save("D:\\project\\project\\ilahiya\\e-learn\\static\\staff\\" + image.filename)
            path = "/static/staff/" + image.filename
            db = Db()
            qry = "update staff set name='" + name + "',department_id='" + department + "',place='" + place + "',email='" + email + "',pin='" + pin + "',contact='" + contact + "',gender='" + gender + "',image='" +path+"',district='" + district + "',housename='" + house + "',dob='" + dob + "',city='" + city + "' where staff_id='" + str(staffid) + "' "
            res = db.update(qry)
            return '''<script>alert('updated');window.location='/viewstaff'</script>'''
        else:
            db = Db()
            qry = "update staff set name='" + name + "',department_id='" + department + "',place='" + place + "',email='" + email + "',pin='" + pin + "',contact='" + contact + "',gender='" + gender + "',district='" + district + "',housename='" + house + "',dob='" + dob + "',city='" + city + "' where staff_id='" + str(
                staffid) + "' "
            res = db.update(qry)
            return '''<script>alert('updated');window.location='/viewstaff'</script>'''
    else:
        db = Db()
        qry = "update staff set name='" + name + "',department_id='" + department + "',place='" + place + "',email='" + email + "',pin='" + pin + "',contact='" + contact + "',gender='" + gender + "',district='" + district + "',housename='" + house + "',dob='" + dob + "',city='" + city + "' where staff_id='" + str(
            staffid) + "' "
        res = db.update(qry)
        return '''<script>alert('updated');window.location='/viewstaff'</script>'''

@app.route("/ahome")
def ahome():
    return render_template("admin/admin-home.html")



@app.route('/editsubject/<id>')
def editsubject(id):
    db=Db()
    qry=" select * from subject"
    res=db.select(qry)
    qry1 = "select * from subject where subject_id='" + id + "'"
    res1=db.selectOne(qry1)
    return render_template("admin/editsubject.html",sub=res,data=res1)


@app.route('/editsubject_post',methods=['post'])
def editsubject_post():
    s_id=request.form['s_id']
    course=request.form['select']
    semester=request.form['textfield']
    subject=request.form['textfield2']
    db=Db()
    # qry="update subject set course_id='"+course+"',subject_name='"+subject+"',semester='"+semester+"' where subject_id='"+str(s_id)+"'"
    q="update subject set course_id='"+course+"',subject_name='"+subject+"',semester='"+semester+"' where subject_id='"+str(s_id)+"'"
    res=db.update(q)
    return '''<script>alert('updated');window.location='/viewsubject'</script>'''

@app.route('/login')
def login():
    return render_template("login.html")


@app.route('/login_post',methods=['post'])
def login_post():
    username=request.form['username']
    password=request.form['password']
    db=Db()
    qry="select * from login where username='"+username+"' and password='"+password+"'"
    res=db.selectOne(qry)
    
    if res is not None:
        session['lid'] = res['login_id']
        if res['usertype']=="admin":
            return render_template("admin/admin-home.html")
        elif res['usertype']=="staff":
            qq="select staff.name,staff.image from staff where login_id='"+str(res['login_id'])+"'"
            dv=db.selectOne(qq)
            if dv is not None:
                session["name"]=dv["name"]
                session["image"]=dv["image"]
            else:
                session["name"]="Staff"
                session["image"]="/static/student/a.jpg"
            return render_template("STAFF/home.html")
        else:
            return render_template("login.html")
    else:
        return render_template("login.html")


@app.route('/subjectallocation')
def subjectallocation():
    db=Db()
    qry="select * from subject"
    res=db.select(qry)
    qry1="select * from staff"
    res1=db.select(qry1)
    return render_template("admin/subjectallocation.html",subject=res,staff=res1)

@app.route('/subjectallocation_post',methods=['post'])
def subjectallocation_post():
    subject=request.form['select']
    staff=request.form['select2']
    db=Db()
    qry="insert into subjectallocation(subject_id,staff_id,date)values('"+subject+"','"+staff+"',curdate())"
    res=db.insert(qry)
    return  subjectallocation()

@app.route('/viewapprovestudent')
def viewapprovestudent():
    db=Db()
    qry="select * from student where status='pending';"
    res=db.select(qry)
    qry1="select * from department"
    res1=db.select(qry1)
    qry2="select * from course"
    data2=db.select(qry2)
    return render_template("admin/viewapprovestudent.html",data=res,data1=res1,data2=data2)


@app.route('/approve_viewapprovestudent/<id>')
def approve_viewapprovestudent(id):
    db=Db()
    qry="update student set status='approved' where student_id='"+id+"'"
    db.update(qry)
    qry="select * from student where status='pending';"
    res=db.select(qry)
    qry1="select * from department"
    res1=db.select(qry1)
    qry2="select * from course"
    data2=db.select(qry2)
    return render_template("admin/viewapprovestudent.html",data=res,data1=res1,data2=data2)

@app.route('/reject_viewapprovestudent/<id>')
def reject_viewapprovestudent(id):
    db=Db()
    qry="update student set status='rejected' where student_id='"+id+"'"
    db.update(qry)
    qry="select * from student where status='pending';"
    res=db.select(qry)
    qry1="select * from department"
    res1=db.select(qry1)
    qry2="select * from course"
    data2=db.select(qry2)
    return render_template("admin/viewapprovestudent.html",data=res,data1=res1,data2=data2)




@app.route('/viewapprovestudent_post',methods=['post'])
def viewapprovestudent_post():
    db=Db()
    crsid=request.form['select2']
    department=request.form['select']
    search=request.form['textfield']

    qry = "select * from student where course_id='"+crsid+"' and name like '%"+search+"%'"
    res = db.select(qry)
    qry1 = "select * from department"
    res1 = db.select(qry1)
    qry2 = "select * from course"
    data2 = db.select(qry2)
    return render_template("admin/viewapprovestudent.html", data=res, data1=res1, data2=data2)


@app.route('/viewcomplaint')
def view_complaint():
    db = Db()
    qry = "SELECT complaint.*,`staff`.`name`, `staff`.`email`,staff.image FROM `staff` INNER JOIN `complaint` ON `complaint`.`user_id`=`staff`.`login_id`union  (SELECT complaint.*,student.name,student.image,student.email from student inner join complaint on complaint.complaint_id=student.login_id)"
    print(qry)
    res = db.select(qry)
    print(res)
    # return render_template("admin/admin_view_comp.html")
    return render_template("admin/viewcomplaint.html",data=res)

@app.route('/admin_view_comp')
def admin_view_comp():
    return render_template("admin/complaint.html")


@app.route('/viewcourse')
def viewcourse():
    db= Db()
    qry="select course.*,department.department_name from course inner join department on department.department_id=course.department_id;"
    res=db.select(qry)
    return render_template("admin/viewcourse.html",data=res)

@app.route('/viewcourse_delete/<cid>')
def viewcourse_delete(cid):
    db= Db()
    qry="delete from course where course_id='"+cid+"'"
    res=db.delete(qry)
    return "<script>alert('Deleted');window.location='/viewcourse'</script>"


@app.route('/viewcoursesearch',methods=['POST'])
def viewcoursesearch():
    db= Db()
    name = request.form["textfield"]
    qry = "select course.*,department.department_name from course inner join department on department.department_id=course.department_id where  course_name like '%" + name + "%';"
    res=db.select(qry)
    return render_template("admin/viewcourse.html",data=res)

@app.route('/delete_department/<id>')
def delete_department(id):
    db=Db()
    qry="delete from department where department_id='"+id+"';"
    res=db.delete(qry)
    return '''<script>alert('Successfully removed');window.location='/viewdepartment';</script>'''

@app.route('/viewdepartment')
def viewdepartment():
    db=Db()
    qry="select * from department;"
    res=db.select(qry)
    return render_template("admin/viewdepartment.html",data=res)


@app.route('/viewdepartmentsearch',methods=['POST'])
def viewdepartmentsearch():
    db=Db()
    name=request.form["textfield"]
    qry="select * from department where department_name like '%"+name+"%';"
    res=db.select(qry)
    return render_template("admin/viewdepartment.html",data=res)


@app.route('/viewreview')
def viewreview():
    db=Db()
    qry="select review.review,review.type,student.name as sn,student.image as si ,staff.name,staff.image from staff inner join review on review.staff_id=staff.login_id inner join student on student.login_id =review.student_id "
    res=db.select(qry)
    return render_template("admin/viewreview.html",data=res)


@app.route('/viewstaffsearch',methods=['POST'])
def viewstaffsearch():
    db=Db()
    name = request.form["textfield"]
    qry= "select * from staff inner join department on department.department_id = staff.department_id where name like '%"+name+"%'"
    res=db.select(qry)
    return render_template("admin/viewstaff.html",data=res)

@app.route('/viewstaff')
def viewstaff():
    db=Db()
    qry= "select * from staff inner join department on department.department_id = staff.department_id"
    res=db.select(qry)
    return render_template("admin/viewstaff.html",data=res)

@app.route('/viewstaff_delete/<staffid>')
def viewstaff_delete(staffid):
    db=Db()
    qry="delete from staff where staff_id='"+staffid+"';"
    res=db.delete(qry)
    return '''<script>alert('Successfully removed');window.location='/viewstaff';</script>'''


@app.route('/viewsubject')
def viewsubject():
    db = Db()
    qry = "select * from course ;"
    res1 = db.select(qry)

    qry="select * from subject inner join  course on subject.course_id=course.course_id"
    res=db.select(qry)
    return render_template("admin/viewsubject.html",data=res,data1=res1)


@app.route('/viewsubject_delete/<sid>')
def viewsubjec_deletet(sid):
    db = Db()
    qry = "delete from subject where subject_id='"+sid+"';"
    res1 = db.delete(qry)
    return '''<script>alert('Successfully removed');window.location='/viewsubject';</script>'''


@app.route('/viewsubjectsearch',methods=['post'])
def viewsubjectsearch():
    db = Db()
    name = request.form["textfield"]
    qry = "select * from course"
    res1 = db.select(qry)
    if name!="":
        qry="select * from subject inner join  course on subject.course_id=course.course_id where subject_name like '%"+name+"%'"
    else:
        name=request.form["select"]
        qry = "select * from subject inner join  course on subject.course_id=course.course_id where subject.course_id ='" + name + "'"
    res=db.select(qry)
    return render_template("admin/viewsubject.html",data=res,data1=res1)


@app.route('/viewsubjectallocation')
def viewsubjectallocation():
    db=Db()
    qry1="select * from department"
    res1=db.select(qry1)
    qry2="select * from course"
    res2=db.select(qry2)
    qry="select * from subjectallocation inner join subject on subject.subject_id=subjectallocation.subject_id inner join staff on staff.login_id=subjectallocation.staff_id inner join course on course.course_id=subject.course_id"
    res=db.select(qry)
    return render_template("admin/viewsubjectallocation.html",data=res,data1=res1,data2=res2)

@app.route('/viewsubjectallocation_post',methods=['post'])
def viewsubjectallocation_post():
    db=Db()
    crsid=request.form['select2']
    departement=request.form['select']
    search=request.form['textfield']
    qry = "select * from subjectallocation inner join subject on subject.subject_id=subjectallocation.subject_id inner join staff on staff.login_id=subjectallocation.staff_id inner join course on course.course_id=subject.course_id where subject.course_id='"+crsid+"' and subject_name like '%"+search+"%'"
    res = db.select(qry)
    qry1 = "select * from department"
    res1 = db.select(qry1)
    qry2 = "select * from course"
    data2 = db.select(qry2)
    return render_template("admin/viewsubjectallocation.html", data=res, data1=res1, data2=data2)



@app.route('/viewsubjectallocation_delete/<allocationid>')
def viewsubjectallocation_delete(allocationid):
    db=Db()
    qry="delete from subjectallocation where allocation_id='"+allocationid+"'"
    res=db.delete(qry)
    return '''<script>alert('Successfully removed');window.location='/viewsubjectallocation';</script>'''

@app.route('/editviewsubjectallocation/<allocationid>')
def editviewsubjectallocation(allocationid):
    db=Db()
    qry="select * from subjectallocation where allocation_id='"+allocationid+"'"
    res=db.selectOne(qry)
    print(res)
    qry1="select * from subject"
    res1=db.select(qry1)
    qry2="select * from staff"
    res2=db.select(qry2)
    return render_template("admin/editsubjectallocation.html",data=res,aid=allocationid,data1=res1,data2=res2)

@app.route('/editviewsubjectallocation_post',methods=['post'])
def editviewsubjectallocation_post():
    subject=request.form['select']
    staff=request.form['select2']
    aid=request.form['aid']
    db=Db()
    qry="update subjectallocation set subject_id='"+subject+"' ,staff_id='"+staff+"' where allocation_id='"+aid+"'  "
    res=db.update(qry)
    return '''<script>alert('updated');windopw.location='/viewsubjectallocation'</script>'''


@app.route('/admin_complaint_replay/<id>')
def admin_complaint_replady(id):
    session["cid"]=id
    return render_template("admin/replay.html")

@app.route('/admin_complaint_replay',methods=['POST'])
def admin_complaint_replay():
    id=str(session["cid"])
    reply=request.form["reply"]
    qry="update complaint set replay='"+reply+"',status='replied' where complaint_id='"+id+"'"
    db=Db()
    db.update(qry)
    return view_complaint()








#----------------------------------------------------------------------------------------
#2nd Module






@app.route('/staff_home')
def staff_home():
    return render_template('STAFF/home.html')




@app.route('/staff_addexam')
def staff_addexam():
    db= Db()
    qry = "select * from subject"
    res=db.select(qry)
    return render_template("STAFF/addexam.html",data1=res)


@app.route('/staff_addexam_post',methods=['post'])
def staff_addexam_post():
    examName=request.form['textfield']
    # staffName=request.form['textfield2']
    subjectName=request.form['select2']
    db=Db()
    qry="insert into exam(exam_name,staff_id,subject_id,date)values('"+examName+"','"+str(session['lid'])+"','"+subjectName+"',curdate())"
    res=db.insert(qry)
    return '''<script>alert('Successfully added');window.location='/staff_addexam'</script>'''




@app.route('/staff_addlecture')
def staff_addlecture():
    db= Db()
    qry = "SELECT `subject`.* FROM `subject` INNER JOIN `subjectallocation` ON `subject`.`subject_id`=`subjectallocation`.`subject_id` WHERE `subjectallocation`.`staff_id`='"+str(session['lid'])+"'"
    res=db.select(qry)
    return render_template("STAFF/addlecture.html",sub=res)


@app.route('/staff_addlecture_post',methods=['post'])
def staff_addlecture_post():
    subject=request.form['select']
    notebook=request.files['fileField']
    notebook.save("D:\\project\\project\\ilahiya\\e-learn\\static\\notes\\"+notebook.filename)
    path = "/static/notes/"+notebook.filename
    content=request.form['textfield']
    db=Db()
    qry="INSERT INTO `notebook`(`content`,`date`,`type`,`file`,`subject_id`)values('"+content+"',curdate(),'lecture_note','"+path+"','"+str(subject)+"')"
    res=db.insert(qry)
    return render_template("STAFF/addlecture.html")



@app.route('/staff_addnotebook')
def staff_addnotebook():
    db=Db()
    qry = "SELECT `subject`.* FROM `subject` INNER JOIN `subjectallocation` ON `subject`.`subject_id`=`subjectallocation`.`subject_id` WHERE `subjectallocation`.`staff_id`='"+str(session['lid'])+"'"
    res=db.select(qry)
    return render_template("STAFF/addnotebook.html",sub=res)


@app.route('/staff_addnotebook_post',methods=['post'])
def staff_addnotebook_post():
    content=request.form['textfield']
    type=request.form['select']
    File=request.files['textfield2']
    subject_id=request.form['select']

    File.save("D:\\project\\project\\ilahiya\\e-learn\\static\\notes\\"+File.filename)
    path='/static/notes/'+File.filename
    db=Db()
    qry="insert into notebook(content,type,file,subject_id)values('"+content+"','"+type+"','"+path+"','"+subject_id+"')"
    res=db.insert(qry)
    return staff_addnotebook()



@app.route('/staff_addpractical')
def staff_addpractical():
    db=Db()
    qry1="SELECT `subject`.* FROM `subject` INNER JOIN `subjectallocation` ON `subject`.`subject_id`=`subjectallocation`.`subject_id` WHERE `subjectallocation`.`staff_id`='"+str(session['lid'])+"'"

    res1=db.select(qry1)
    return render_template("STAFF/addpractical.html",data1=res1)


@app.route('/staff_addpractical_post',methods=['post'])
def staff_addpractical_post():
    practical=request.form['practical']
    subject=request.form['select2']
    db=Db()
    qry="insert into`practical`(`practical`,`staff_id`,`subject_id`,`date`,`time`)values('"+practical+"','"+str(session['lid'])+"','"+subject+"',curdate(), curtime())"
    res=db.insert(qry)
    return '''<script>alert('Added');window.location='/staff_addpractical'</script>'''


@app.route('/staff_addquestion/<id>')
def staff_addquestion(id):
    # db=Db()
    # qry="select * from exam where `staff_id`='"+str(session["lid"])+"'"
    # res=db.select(qry)
    session["eid"]=id
    return render_template("STAFF/addquestion.html")

@app.route('/staff_addquestion_post',methods=['post'])
def staff_addquestion_post():
    examName=str(session["eid"])
    questionName=request.form['textfield']
    answer=request.form['textfield2']
    mark=request.form['textfield3']
    op1=request.form["op1"]
    op2=request.form["op2"]
    op3=request.form["op3"]
    op4=request.form["op4"]
    db=Db()
    qry="INSERT INTO examquistion(`exam_id`,`quistion_name`,`answer`,`mark`,optiona,optionb,optionc,optiond)VALUES('"+examName+"','"+questionName+"','"+answer+"','"+mark+"','"+op1+"','"+op2+"','"+op3+"','"+op4+"')"
    res=db.insert(qry)
    print(qry)
    return staff_addquestion(examName)



@app.route('/staff_addquestionbank')
def staff_addquestionbank():
    db=Db()
    # qry1="select * from staff"
    # res1=db.select(qry1)
    qry2="select * from subject"
    res2=db.select(qry2)
    return render_template("STAFF/addquestionbank.html",data2=res2)


@app.route('/staff_addquestionbank_post',methods=['post'])
def staff_addquestionbank_post():
    # staff=request.form['select']
    subject=request.form['select2']
    question=request.form['textarea']
    answer=request.form['textarea2']
    db=Db()
    qry="INSERT INTO `quistionbank`(`quistions`,`subject_id`,`staff_id`,`answer`) VALUES('"+question+"','"+subject+"','"+str(session['lid'])+"','"+answer+"')"
    res=db.insert(qry)
    return staff_addquestionbank()


@app.route('/arch_chat_user/<id>')
def arch_chat(id):
    return render_template("Arch/fur_chat.html",toid=id)
@app.route("/chatview",methods=['post'])
def chatview():
    db=Db()
    qry="select * from student where status='approved'"
    res=db.select(qry)
    return jsonify(data=res)

@app.route("/insert_chat/<senid>/<msg>")
def insert_chat(senid,msg):
    db=Db()
    qry="insert into chat (dateandtime,from_id,to_id,message) values (now(),'"+str(session["lid"])+"','"+senid+"','"+msg+"')"
    db.insert(qry)
    return jsonify(status="ok")
@app.route("/viewmsg/<senid>")        # refresh messages chatlist
def viewmsg(senid):
    uid=senid
    qry = "select from_id,message as msg,dateandtime as date from chat where (from_id='"+str(session["lid"])+"' and to_id='" + uid + "') or ((from_id='" + uid + "' and to_id='"+str(session["lid"])+"')) order by chat_id asc"
    c = Db()
    p = c.select(qry)
    print(p)
    return jsonify(data=p)
@app.route('/staff_chat')
def staff_chat():
    return render_template("STAFF/fur_chat.html")

@app.route('/staff_chat_post',methods=['post'])
def staff_chat_post():
    return render_template("STAFF/chat.html")



@app.route('/staff_editexam')
def staff_editexam():
    db=Db()
    qry="select * from exam where exam_id="'+id+'""
    res=db.selectOne(qry)
    return render_template("STAFF/editexam.html",data=res)

@app.route('/staff_editexam_post',methods=['post'])
def staff_editexam_post():
    examName=request.form['textfield']
    staffName=request.form['select']
    subjectName=request.form['select2']
    db=Db()
    qry="UPDATE `exam` SET exam_name='"+examName+"' ,staff_id="'+staffName+'" ,subject_id="'+subjectName+'""
    res=db.update(qry)
    return '''<script>alert('updated');windopw.location='/staff_editexam'</script>'''



@app.route('/staff_editlecture/<id>')
def staff_editlecture(id):
    db=Db()
    qry="SELECT * FROM notebook WHERE TYPE=lecture AND notebook_id='"+id+"'"
    res=db.selectOne(qry)
    return render_template("STAFF/editlecture.html",data=res)


@app.route('/staff_editlecture_post',methods=['post'])
def staff_editlecture_post():
    subject=request.form['select']
    notebook=request.fom['fileField']
    db=Db()
    qry="update notewbook set subject_id='"+subject+"',notebook_id='"+notebook+"'"
    res=db.update(qry)
    return '''<script>alert('updated');windopw.location='/staff_editlecture'</script>'''




@app.route('/staff_editnotebook/<id>')
def staff_editnotebook(id):
    db=Db()
    qry="select * from notebook where type=notebook and notebook_id='"+id+"'"
    res=db.seleteOne(qry)
    return render_template("STAFF/editnotebook.html",data=res)

@app.route('/staff_editnotebook_post',methods=['post'])
def staff_editnotebook_post():
    content=request.form['textfield']
    type=request.form['select']
    File=request.form['textfield2']
    db=Db()
    qry="UPDATE notebook SET `content`='"+content+"',`type`='"+type+"',`file`='"+File+"'"
    res=db.update(qry)
    return '''<script>alert('updated');windopw.location='/staff_editnotebook'</script>'''

@app.route('/staff_editpractical')
def staff_editpractical():
    db=Db()
    qry="select * from practical where"
    return render_template("STAFF/editpractical.html")


@app.route('/staff_editpractical_post',methods=['post'])
def staff_editpractical_post():
    staff=request.form['select']
    subject=request_started.form['select2']

    return render_template("STAFF/addpractical.html")



@app.route('/staff_editquestion')
def staff_editquestion():
    return render_template("STAFF/editquestion.html")


@app.route('/staff_editquestion_post',methods=['post'])
def staff_editquestion_post():
    examName=request.form['select']
    questionName=request.form['textfield']
    answer=request.form['textfield2']
    mark=request.form['textfield3']

    return render_template("STAFF/editquestion.html")







@app.route('/staff_viewallocation')
def staff_viewallocation():
    qry="select * from subjectallocation inner join subject on subject.subject_id=subjectallocation.subject_id inner join course on course.course_id=subject.course_id where staff_id='"+str(session["lid"])+"'"
    db=Db()
    res=db.select(qry)
    return render_template("STAFF/viewalloction.html",data=res)

@app.route('/staff_send_comp')
def staff_send_comp():
    db=Db()
    
    return render_template("STAFF/send_complaintabout_student.html")
@app.route('/staff_send_comp_post',methods=['POST'])
def staff_send_comp_post():
    db=Db()
    textarea=request.form["textarea"]
    qry="insert into complaint(user_id,user_type,complaint,replay,date,status)value('"+str(session["lid"])+"','staff','"+textarea+"','pending',curdate(),'pending')"
    db.insert(qry)
    return render_template("STAFF/send_complaintabout_student.html")

@app.route('/staff_viewcomplaint')
def staff_viewcomplaint():
    db=Db()
    qry="SELECT * from `complaint` where user_id='"+str(session['lid'])+"' and user_type='staff'"
    res=db.select(qry)
    return render_template("STAFF/viewcomplaint.html",data=res)


@app.route('/staff_viewcomplaint_post',methods=['post'])
def staff_viewcomplaint_post():
    return render_template("STAFF/viewcomplaint.html")


@app.route('/staff_viewexam')
def staff_viewexam():
    db=Db()
    qry="SELECT * FROM `exam` INNER JOIN `subject` ON `subject`.`subject_id`=`exam`.`subject_id` WHERE `exam`.`staff_id`='"+str(session['lid'])+"'"
    res=db.select(qry)
    return render_template("STAFF/viewexam.html",data=res)


@app.route("/staff_delete_exam/<id>")
def staff_delete_exam(id):
    db=Db()
    qry="delete from exam where exam_id='"+id+"'"
    db.delete(qry)
    return staff_viewexam()


@app.route("/delete_lecture/<id>")
def delete_lecture(id):
    db=Db()
    qry="delete from notebook where notebook_id='"+id+"'"
    db.delete(qry)
    return staff_viewlecture()
@app.route('/staff_viewexam_post',methods=['post'])
def staff_viewexam_post():
    return render_template("STAFF/viewexam.html")

@app.route("/vc")
def vc():
    return render_template("staff/vcall.html")

@app.route('/staff_viewexamresult/<id>')
def staff_viewexamresult(id):
    db=Db()

    qry="select * from student inner join examresult on examresult.student_id=student.login_id inner join emotion on emotion.exam_id=examresult.exam_id where examresult.exam_id='"+id+"' and emotion.student_id=examresult.student_id"
    data=db.select(qry)
    qq="select sum(mark) as s from examquistion where exam_id='"+id+"'"
    f=db.selectOne(qq)
    return render_template("STAFF/viewexamresult.html",data=data,s=f["s"])

@app.route('/staff_viewexamresult_post',methods=['post'])
def staff_viewexamresult_post():
    return render_template("STAFF/viewexamresult.html")


@app.route('/staff_viewhelp')
def staff_viewhelp():
    db=Db()
    qry="SELECT `help`.*,`student`.`name`,`subject`.`subject_name` FROM `student` INNER JOIN `help` ON `student`.`login_id`=`help`.`student_id` INNER JOIN `subject` ON `subject`.`subject_id`=`help`.`subject_id` where help.subject_id in(select subject_id from subjectallocation where staff_id='"+str(session["lid"])+"')"
    res=db.select(qry)
    return render_template("STAFF/viewhelp.html",data=res)


@app.route('/staff_viewhelp_post',methods=['post'])
def staff_viewhelp_post():
    return render_template("STAFF/viewhelp.html")




@app.route('/staff_viewlecture')
def staff_viewlecture():
    db=Db()
    qry="SELECT * FROM `notebook` INNER JOIN subject ON notebook.`subject_id`=`SUBJECT`.`subject_id`  inner join subjectallocation on subject.subject_id=subjectallocation.subject_id where `notebook`.type='lecture_note' and staff_id='"+str(session["lid"])+"'"
    res=db.select(qry)
    return render_template("STAFF/viewlecture.html",data=res)

@app.route('/staff_viewlecture_post',methods=['post'])
def staff_viewlecture_post():
    return render_template("STAFF/viewlecture.html")


@app.route('/staff_viewnotebook')
def staff_viewnotebook():
    db=Db()
    return render_template("STAFF/viewnotebook.html")

@app.route('/staff_viewmotebook_post',methods=['post'])
def staff_viewmotebook_post():
    return render_template("STAFF/viewnotebook.html")


@app.route('/staff_viewpractical')
def staff_viewpractical():
    qry="select * from practical inner join subject on subject.subject_id=practical.subject_id where staff_id='"+str(session["lid"])+"'"
    db=Db()
    res=db.select(qry)
    print(res)
    return render_template("STAFF/viewpractical.html",data=res)

@app.route("/delete_practical/<id>")
def delete_practical(id):
    qry="delete from practical where practical_id='"+id+"'"
    db=Db()
    res=db.delete(qry)
    return staff_viewpractical()


@app.route('/staff_viewprofile')
def staff_viewprofile():
    db=Db()
    qry="SELECT * FROM staff WHERE login_id='"+str(session['lid'])+"'"
    res=db.selectOne(qry)
    return render_template("STAFF/viewprofile.html",data=res)



@app.route('/staff_viewprofile_post',methods=['post'])
def staff_viewprofile_post():
    return render_template("STAFF/viewprofile.html")


@app.route('/staff_viewquestion/<id>')
def staff_viewquestion(id):
    db=Db()
    qry="select * from examquistion where exam_id='"+id+"'"
    res=db.select(qry)
    return render_template("STAFF/viewquestion.html",data=res)
@app.route('/staff_del_q/<id>/<ee>')
def staff_del_q(id,ee):
    db=Db()
    qry="delete from examquistion where quistion_id='"+id+"'"
    res=db.delete(qry)
    return staff_viewquestion(ee)

@app.route('/staff_viewquestion_post',methods=['post'])
def staff_viewquestion_post():
    return render_template("STAFF/viewquestion.html")


@app.route('/staff_viewquestionbank')
def staff_viewqustionbank():
    db=Db()
    qry="SELECT `quistionbank`.*,`staff`.`name`,`subject`.`subject_name` FROM `quistionbank` INNER JOIN `staff` ON `quistionbank`.`staff_id`=`staff`.`login_id` INNER JOIN `subject` ON `quistionbank`.`subject_id`=`subject`.`subject_id`"
    res=db.select(qry)
    return render_template("STAFF/viewquestionbank.html",data=res)

@app.route("/delete_questionbank/<id>")
def delete_questionbank(id):
    qry="delete from quistionbank where quistion_id='"+id+"'"
    d=Db()
    d.delete(qry)
    return staff_viewqustionbank()

@app.route("/edit_questionbank/<id>")
def edit_questionbank(id):
    qry="select * from quistionbank where quistion_id='"+id+"'"
    d=Db()
    res=d.selectOne(qry)
    qry2="select * from subject"
    res2=d.select(qry2)
    return render_template("STAFF/editquestionbank.html",data=res,data2=res2)



@app.route('/staff_editquestionbank_post',methods=['post'])
def staff_editquestionbank_post():
    id=request.form['id']
    subject=request.form['select2']
    qustion=request.form['textarea']
    answer=request.form['textarea2']
    qry="update quistionbank set quistions='"+qustion+"',subject_id='"+subject+"',answer='"+answer+"' where quistion_id='"+id+"'"
    d=Db()
    res=d.update(qry)
    return staff_viewqustionbank()



#------------------------------------------------------------30/3/2022


@app.route('/login_post_student', methods=["post"])
def login_post_student():
    db = Db()
    username = request.form["username"]
    password = request.form["password"]
    qry = "SELECT * FROM login WHERE username='" + username + "' AND PASSWORD='" + password + "'"
    res = db.selectOne(qry)
    if res is not None:
        return jsonify (status="ok",log_id=res['login_id'],type=res['usertype'])
    else:
        return jsonify(status="no")
    


@app.route('/viewstudent_android', methods=['post'])
def viewstudent_android():
    db=Db()
    lid=request.form['lid']
    qry="SELECT * FROM student WHERE login_id='"+lid+"'"
    res = db.selectOne(qry)
    if res is not None:
        return jsonify(status="ok",name=res['name'],phone=res['contact'],photo=res['image'],age=res['dob'],gender=res['gender'],standered=res['place'])
    else:
        return jsonify(status="no")

@app.route('/viewmaterial_student',methods=['post'])
def viewmaterial_student():
    db=Db()
    ls=[]
    lid=request.form["lid"]
    qry="select * from subject inner join notebook on notebook.subject_id=subject.subject_id inner join subjectallocation on subjectallocation.subject_id=subject.subject_id inner join staff on staff.login_id=subjectallocation.staff_id where subject.course_id in( select course_id from student where login_id='"+lid+"')"
    res=db.select(qry)
    print(res)
    if len(res)==0:
        return jsonify(status="no")
    else:
        return jsonify(status="ok",users=res)


        
@app.route('/viewwork_student',methods=['POST'])
def viewwork_student():
    db=Db()
    log_id=request.form['lid']
    qry= "select * from subject where course_id in (select course_id from student where login_id='"+log_id+"')"
    res=db.select(qry)
    print(qry)
    print(res)
    return jsonify(status="ok", users=res)

@app.route('/viewnumericalproblem_student', methods=['post'])
def viewnumericalproblem_student():
    lid=request.form['lid']
    db= Db()
    qry="select * from quistionbank where subject_id='"+lid+"'"
    res=db.select(qry)
    print(res)
    if len(res)==0:
            return jsonify(status="no")
    else:
        return jsonify(status="ok",users=res)

@app.route('/viewpract_student',methods=['POST'])
def viewpract_student():
    db=Db()
    log_id=request.form['lid']
    qry= "select * from subject inner join practical on practical.subject_id = subject.subject_id where course_id in (select course_id from student where login_id='"+log_id+"')"
    res=db.select(qry)
    print(qry)
    print(res)
    return jsonify(status="ok", users=res)


@app.route('/viewexam_student',methods=['POST'])
def viewexam_student():

    lid=request.form["lid"]
    db=Db()
    qry="select * from exam inner join subject on exam.subject_id=subject.subject_id where course_id in (select course_id from student where login_id='"+lid+"') and exam.date=curdate()"
    res=db.select(qry)
    print(qry)
    print(res)
    if len(res)==0:
        return jsonify(status="no")
    else:
        return jsonify(status="ok",users=res)

@app.route('/loadquestions_student' ,methods=['post'])
def loadquestions_student():
    ex_id=request.form['ex_id']
    db=Db()
    qry="select * from examquistion where exam_id='"+ex_id+"'"
    res=db.select(qry)

    if len(res)==0:
        
        return jsonify(status="no")
    else:
        
        return jsonify(status="ok", ln=len(res),users=res)

@app.route('/markinsert_student', methods=['post'])
def markinsert_student():
    db=Db()
    mark=request.form['mark']
    ex_id=request.form['ex_id']
    lid=request.form['lid']
    qry = "INSERT INTO  `examresult`(student_id,result,exam_id,date)VALUES ('"+lid+"','"+mark+"','"+ex_id+"',CURDATE())"
    res= db.insert(qry)
    return jsonify(status="ok")



@app.route('/emotion_student',methods=['POST'])
def emotion_student():
    db= Db()
    static_path="D:\\project\\project\\ilahiya\\e-learn\\static\\emotion\\"
    ex_id=request.form['ex_id']
    s_id=request.form['lid']
    file = request.files["pic"]
    file.save(static_path + "a.jpg")
    path = "/static/" + file.filename

    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Dense, Dropout, Flatten
    from tensorflow.keras.layers import Conv2D
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras.layers import MaxPooling2D
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    import os

    import cv2
    import numpy as np

    frame=cv2.imread(static_path + "a.jpg")

    print(static_path + "a.jpg")

    model = Sequential()

    model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=(48,48,1)))
    model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Conv2D(128, kernel_size=(3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(128, kernel_size=(3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(0.25))

    model.add(Flatten())
    model.add(Dense(1024, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(7, activation='softmax'))

    model.load_weights(r'D:\project\project\ilahiya\e-learn\model.h5')

    # prevents openCL usage and unnecessary logging messages
    cv2.ocl.setUseOpenCL(False)

    # dictionary which assigns each label an emotion (alphabetical order)
    emotion_dict = {0: "Angry", 1: "Disgusted", 2: "Fearful", 3: "Happy", 4: "Neutral", 5: "Sad", 6: "Surprised"}

    # start the webcam feed
    facecasc = cv2.CascadeClassifier(r'D:\project\project\ilahiya\e-learn\haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facecasc.detectMultiScale(gray,scaleFactor=1.3, minNeighbors=5)

    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y-50), (x+w, y+h+10), (255, 0, 0), 2)
        roi_gray = gray[y:y + h, x:x + w]
        cropped_img = np.expand_dims(np.expand_dims(cv2.resize(roi_gray, (48, 48)), -1), 0)
        prediction = model.predict(cropped_img)
        # print(prediction)
        maxindex = int(np.argmax(prediction))
        print(emotion_dict[maxindex])
        qry="INSERT INTO `emotion`  (student_id,exam_id,emotion,date) VALUES ('"+s_id+"','"+ex_id+"','"+emotion_dict[maxindex]+"',curdate())"
        res= db.insert(qry)
        print(qry)    
    return jsonify(status="ok" )
@app.route('/viewexam_resultt_student',methods=['post'])
def viewexam_result():
    db=Db()
    s_id=request.form['lid']
    qry="SELECT `subject`.*,`examresult`.*,`exam`.`date`,exam.exam_id FROM `exam` INNER JOIN `examresult` ON `exam`.`exam_id`=`examresult`.`exam_id` inner join subject on subject.subject_id=exam.subject_id WHERE `student_id`='"+s_id+"'"
    res= db.select(qry)
    return jsonify(status="ok",users=res)

@app.route("/arc_all_view",methods=['POST'])
def arc_all_view():
    qry="SELECT * from staff"
    db=Db()
    res= db.select(qry)
    return jsonify(status="ok",data=res)

@app.route("/and_srch_arc",methods=['POST'])
def and_srch_arc():
    name=request.form["name"]
    qry="SELECT * from staff where name like '%"+name+"%'"
    print(qry)
    db=Db()
    res= db.select(qry)
    return jsonify(status="ok",data=res)

@app.route("/and_send_msg",methods=['post'])
def and_send_msg():
    sid=request.form['fid']
    rid=request.form['toid']
    msg=request.form['msg']
    d=Db()
    qry="insert into chat(from_id,to_id,message,dateandtime)values('"+sid+"','"+rid+"','"+msg+"',curdate())"
    res=d.insert(qry)
    if res>0:
        return jsonify(status='ok')
    else:
        return jsonify(status='no')

@app.route("/and_view_msg",methods=['post'])
def and_view_msg():
    sid = request.form['fid']
    rid = request.form['toid']
    lmid = request.form['lastmsgid']
    d=Db()
    qry="select  from_id,message as msg,dateandtime as date,chat_id as cid from chat where chat_id>'"+lmid+"' AND ((from_id='"+rid+"' and  to_id='"+sid+"') or (from_id='"+sid+"' and to_id='"+rid+"')  )  order by chat_id asc"
    res=d.select(qry)
    if res is not None:
        return jsonify(status='ok',data=res)
    else:
        return  jsonify(status='no')

@app.route('/complaint', methods=['post'])
def complaint():
    db=Db()
    complaint=request.form['complaint']
    userid=request.form['uid']
    # rid = request.form["rid"]
    qry="insert into complaint values(null,'"+userid+"','student','"+complaint+"','pending',curdate(),'pending')"
    res=db.insert(qry)
    if res>0:
        return jsonify(status="ok")
    else:
        return jsonify(status="no")

@app.route('/complaint_rv', methods=['post'])
def complaint_rv():
    db=Db()
    complaint=request.form['complaint']
    userid=request.form['uid']
    rid = request.form["rid"]
    qry="insert into review(review,student_id,staff_id,type)values('"+complaint+"','"+userid+"','"+rid+"',curdate())"
    res=db.insert(qry)
    if res>0:
        return jsonify(status="ok")
    else:
        return jsonify(status="no")


@app.route('/vw_reply', methods=['POST'])
def vw_reply():
    lid= request.form["lid"]
    # rid=request.form["rid"]
    qry="SELECT * FROM `complaint` WHERE `user_id`='"+lid+"'"
    c=Db()
    res=c.select(qry)
    if res is not None:
        return jsonify(status='ok',data=res)
    else:
        return jsonify(status='no')




@app.route('/view_st_course', methods=['POST'])
def view_st_course():
    
    qry="SELECT * FROM course"
    c=Db()
    res=c.select(qry)
    if res is not None:
        return jsonify(status='ok',data=res)
    else:
        return jsonify(status='no')


@app.route('/reg',methods=['post'])
def reg():
    db=Db()
    name=request.form['name']
    gender=request.form['gender']
    dob=request.form['dob']
    place=request.form['place']
    pin=request.form['pin']
    email=request.form['email']
    phone=request.form['phone']
    pic=request.form['pic']
    password=request.form['pass']
    course=request.form["course"]
    import time
    import base64
    timestr=time.strftime("%Y%m%d-%H%M%S")
    a=base64.b64decode(pic)
    fh=open("D:\\project\\project\\ilahiya\\e-learn\\static\\student\\"+timestr+".jpg","wb")
    fh.write(a)
    fh.close()
    path="/static/User/"+timestr+".jpg"
    qr1="insert into login(username,password,usertype)values('"+email+"','"+password+"','student')"
    res=db.insert(qr1)
    qry="insert into student(name,image,dob,contact,email,place,pin,login_id,course_id,status)values('"+name+"','"+path+"','"+dob+"','"+phone+"','"+email+"','"+place+"','"+pin+"','"+str(res)+"','"+course+"','pending')"
    res=db.insert(qry)
    if res>0:
        return jsonify(status="ok")
    else:
        return jsonify(status="no")

if __name__ == '__main__':
    app.run(debug=True, port=5000,host='0.0.0.0')