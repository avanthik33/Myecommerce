/*
SQLyog Community Edition- MySQL GUI v8.03 
MySQL - 5.6.12-log : Database - e-learn
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`e-learn` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `e-learn`;

/*Table structure for table `chat` */

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `chat_id` int(11) NOT NULL AUTO_INCREMENT,
  `from_id` int(11) DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `message` varchar(500) DEFAULT NULL,
  `dateandtime` datetime DEFAULT NULL,
  PRIMARY KEY (`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `chat` */

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `complaint` varchar(500) DEFAULT NULL,
  `replay` varchar(500) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

/*Table structure for table `course` */

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `total_sem` int(11) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `course` */

insert  into `course`(`course_id`,`course_name`,`department_id`,`total_sem`) values (1,'BCA',0,6),(2,'asd',0,6),(5,'gg',1,3),(6,'asd',1,0),(8,'asd',4,6),(11,'BCA',14,6),(12,'BSC PHYSICS',15,6),(13,'BA ENGLISH',16,6),(14,'COMPUTER SCIENCE ENGINEERING',17,8);

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `department_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

/*Data for the table `department` */

insert  into `department`(`department_id`,`department_name`) values (14,'computer science'),(15,'science'),(16,'english'),(17,'BTECH');

/*Table structure for table `emotion` */

DROP TABLE IF EXISTS `emotion`;

CREATE TABLE `emotion` (
  `emotion_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `examquistion_id` int(11) DEFAULT NULL,
  `emotion` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`emotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `emotion` */

/*Table structure for table `exam` */

DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_name` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `exam` */

/*Table structure for table `examquistion` */

DROP TABLE IF EXISTS `examquistion`;

CREATE TABLE `examquistion` (
  `quistion_id` int(11) NOT NULL AUTO_INCREMENT,
  `quistion_name` varchar(100) DEFAULT NULL,
  `answer` varchar(800) DEFAULT NULL,
  `mark` varchar(200) DEFAULT NULL,
  `exam_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`quistion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `examquistion` */

/*Table structure for table `examresult` */

DROP TABLE IF EXISTS `examresult`;

CREATE TABLE `examresult` (
  `result_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `result` varchar(200) DEFAULT NULL,
  `exam_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`result_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `examresult` */

/*Table structure for table `help` */

DROP TABLE IF EXISTS `help`;

CREATE TABLE `help` (
  `help_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`help_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `help` */

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `usertype` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

/*Table structure for table `notebook` */

DROP TABLE IF EXISTS `notebook`;

CREATE TABLE `notebook` (
  `notebook_id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(400) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `file` varchar(500) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`notebook_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `notebook` */

/*Table structure for table `practical` */

DROP TABLE IF EXISTS `practical`;

CREATE TABLE `practical` (
  `practical_id` int(11) NOT NULL AUTO_INCREMENT,
  `practical` varchar(500) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`practical_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `practical` */

/*Table structure for table `quistionbank` */

DROP TABLE IF EXISTS `quistionbank`;

CREATE TABLE `quistionbank` (
  `quistion_id` int(11) NOT NULL AUTO_INCREMENT,
  `quistions` varchar(800) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `answer` varchar(800) DEFAULT NULL,
  PRIMARY KEY (`quistion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `quistionbank` */

/*Table structure for table `review` */

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `review` varchar(400) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `type` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `review` */

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) DEFAULT NULL,
  `login_id` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pin` int(50) DEFAULT NULL,
  `contact` bigint(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `housename` varchar(100) DEFAULT NULL,
  `dob` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `staff` */

insert  into `staff`(`staff_id`,`department_id`,`login_id`,`name`,`place`,`email`,`pin`,`contact`,`gender`,`image`,`district`,`housename`,`dob`,`city`,`state`) values (1,2,NULL,'riss technology','ssssdd','aa@gmail.com',345,98999999,'male','/static/staff/1.jpg',NULL,'calicut','2021-12-08','calicut','bxxxx'),(2,6,NULL,'riss','dtydyd','aa@gmail.com',6543,98999999,'male','/static/staff/5.jpg',NULL,'dtgdy','2021-12-07','ytgui','fruyf'),(3,8,NULL,'jack','california','aa@gmail.com',345,989564329,'others','/static/staff/3.jpg',NULL,'homlu','2021-12-21','newyork','dchy'),(5,5,NULL,'avav','calicut','aa@gmail.com',345,98999999,'male','/static/staff/496443016.jpg','None','calicut','2021-12-27','mnjhnj','calicut'),(6,5,NULL,'gvcgv','ssssdd','aa@gmail.com',977999,98999999,'male','/static/staff/2.jpg',NULL,'kkkk','2022-02-09','kkkkk','lllll'),(7,14,NULL,'staff 1','place 1','staff1@gmail.com',1000,10000000000,'male','/static/staff/1.jpg',NULL,'house 1','2022-02-03','city 1','district 1'),(8,15,NULL,'staff2','staff2 place','staff2@gamil.com',20000,20000000,'female','/static/staff/2.jpg',NULL,'staff2 house','2022-02-16','staff2 city','staff district');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `contact` bigint(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `pin` int(11) DEFAULT NULL,
  `login_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student` */

/*Table structure for table `subject` */

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) DEFAULT NULL,
  `subject_name` varchar(50) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `subject` */

insert  into `subject`(`subject_id`,`course_id`,`subject_name`,`semester`) values (9,11,'transaction','1'),(10,1,'discreate','1'),(11,1,'fundematal maths','1'),(12,9,'ways with words','3'),(13,13,'hgvghh','4'),(14,9,'asss','4'),(15,9,'absss','2');

/*Table structure for table `subjectallocation` */

DROP TABLE IF EXISTS `subjectallocation`;

CREATE TABLE `subjectallocation` (
  `allocation_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`allocation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `subjectallocation` */

insert  into `subjectallocation`(`allocation_id`,`subject_id`,`staff_id`,`date`) values (1,9,1,'2022-02-08');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
